  <script src="{{asset('user_asset/media/jui/js/jquery.min.js')}}" type="text/javascript"></script>
  <!-- <script src="{{asset('user_asset/media/jui/js/js.js')}}" type="text/javascript"></script> -->
  <script src="{{asset('user_asset/media/jui/js/jquery-noconflict.js')}}" type="text/javascript"></script>
  <script src="{{asset('user_asset/media/jui/js/jquery-migrate.min.js')}}" type="text/javascript"></script>
  <script src="{{asset('user_asset/media/system/js/caption.js')}}" type="text/javascript"></script>
  <script src="{{asset('user_asset/media/jui/js/bootstrap.min.js')}}" type="text/javascript"></script>
	<script src="{{asset('user_asset/templates/vg_news24/js/bootstrap.js')}}"></script>
	<script src="{{asset('user_asset/templates/vg_news24/js/retina.js')}}"></script>
	<script src="{{asset('user_asset/templates/vg_news24/js/tinyscrollbar.js')}}"></script>
	<script src="{{asset('user_asset/templates/vg_news24/js/caroufredsel.js')}}"></script>
	
	
    <script src="{{asset('user_asset/templates/vg_news24/js/nicescroll.js')}}"></script>
		
	<script src="{{asset('user_asset/templates/vg_news24/js/jquery.mobilemenu.js')}}"></script>
	<script src="{{asset('user_asset/templates/vg_news24/js/jquery.ticker.js')}}"></script>
	<script src="{{asset('user_asset/templates/vg_news24/js/custom.js')}}"></script>
	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
	<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>

