
	<footer class="clearfix">

					<div class="n_footer_head">
				<div class="n_content clearfix">
				
					

<div class="custom"  >
	<div><a class="n_footer_logo pull-left" href="#"><img src="images/logo/footer-logo.png" alt="" /></a></div></div>

				
											<a href="#" class="n_footer_back_to_top pull-right"><i class="icon-caret-up"></i>&nbsp;&nbsp;Back to top</a>
									
				</div>
			</div>
		
		<div class="n_content clearfix">
			<div class="row-fluid">
				<div class="span2">
				
					<div class="vg-bottom ">

<div class="custom"  >
	<div class="n_footer_titles"><span>Metcreative.com</span><br /> <span>Contact With Metcreative</span><br /> <span>Legal</span><br /> <span>About Us</span></div></div>
</div>
			
				</div>
				<div class="span10">
			
					<div class="n_content clearfix">
					
						<div class="vg-bottom _menu"><ul id="vg-footermenu-118" class="vg-footer-menu-list n_footer_link_line ">
<li class="item-141"><a href="#" >Business</a></li><li class="item-142"><a href="#" >Markets</a></li><li class="item-143"><a href="#" >World</a></li><li class="item-144"><a href="#" >Politics</a></li><li class="item-145"><a href="#" >Technology</a></li><li class="item-146"><a href="#" >Opinion</a></li><li class="item-147"><a href="#" >Money</a></li><li class="item-148"><a href="#" >Pictures</a></li><li class="item-149"><a href="#" >Videos</a></li><li class="item-150"><a href="#" >Site Index</a></li></ul>
<div class="clearfix"></div>

<script>
jQuery(document).ready(function($){
	$('#vg-footermenu-118').mobileMenu({
		defaultText: 'Footer Menu A',
		className: 'vg-footermenu-select-118',
		subMenuDash: '&ndash;&ndash;'
	});
	$('.vg-footermenu-select-118').addClass('n_responsive_nav');
	$(".vg-footermenu-select-118").each(function(){  
		$(this).wrap('<div class="n_header_responsive_nav">');
	});
}); 
</script>
</div><div class="vg-bottom _menu"><ul id="vg-footermenu-119" class="vg-footer-menu-list n_footer_link_line ">
<li class="item-151"><a href="#" >Twitter</a></li><li class="item-152"><a href="#" >Facebook</a></li><li class="item-153"><a href="#" >Linked In</a></li><li class="item-154"><a href="#" >RSS</a></li><li class="item-155"><a href="#" >Youtube</a></li><li class="item-156"><a href="#" >Podcast</a></li><li class="item-157"><a href="#" >Newsletter</a></li><li class="item-158"><a href="#" >Mobile</a></li></ul>
<div class="clearfix"></div>

<script>
jQuery(document).ready(function($){
	$('#vg-footermenu-119').mobileMenu({
		defaultText: 'Footer Menu B',
		className: 'vg-footermenu-select-119',
		subMenuDash: '&ndash;&ndash;'
	});
	$('.vg-footermenu-select-119').addClass('n_responsive_nav');
	$(".vg-footermenu-select-119").each(function(){  
		$(this).wrap('<div class="n_header_responsive_nav">');
	});
}); 
</script>
</div><div class="vg-bottom _menu"><ul id="vg-footermenu-120" class="vg-footer-menu-list n_footer_link_line ">
<li class="item-159"><a href="#" >Bankruptcy Law</a></li><li class="item-160"><a href="#" >California Legal</a></li><li class="item-161"><a href="#" >New York Legal</a></li><li class="item-162"><a href="#" >Security Laws</a></li><li class="item-163"><a href="#" >Add Choices</a></li></ul>
<div class="clearfix"></div>

<script>
jQuery(document).ready(function($){
	$('#vg-footermenu-120').mobileMenu({
		defaultText: 'Footer Menu C',
		className: 'vg-footermenu-select-120',
		subMenuDash: '&ndash;&ndash;'
	});
	$('.vg-footermenu-select-120').addClass('n_responsive_nav');
	$(".vg-footermenu-select-120").each(function(){  
		$(this).wrap('<div class="n_header_responsive_nav">');
	});
}); 
</script>
</div><div class="vg-bottom _menu"><ul id="vg-footermenu-121" class="vg-footer-menu-list n_footer_link_line ">
<li class="item-164"><a href="#" >Privacy Policy</a></li><li class="item-165"><a href="#" >Terms of Use</a></li><li class="item-166"><a href="#" >Advertise with Us</a></li><li class="item-167"><a href="#" >Copyright</a></li></ul>
<div class="clearfix"></div>

<script>
jQuery(document).ready(function($){
	$('#vg-footermenu-121').mobileMenu({
		defaultText: 'Footer Menu D',
		className: 'vg-footermenu-select-121',
		subMenuDash: '&ndash;&ndash;'
	});
	$('.vg-footermenu-select-121').addClass('n_responsive_nav');
	$(".vg-footermenu-select-121").each(function(){  
		$(this).wrap('<div class="n_header_responsive_nav">');
	});
}); 
</script>
</div><div class="vg-bottom _menu"><ul id="vg-footermenu-122" class="vg-footer-menu-list n_footer_link_line ">
<li class="item-168"><a href="#" >Sign in</a></li><li class="item-169"><a href="#" >Register</a></li><li class="item-170"><a href="#" >Forgot Password</a></li></ul>
<div class="clearfix"></div>

<script>
jQuery(document).ready(function($){
	$('#vg-footermenu-122').mobileMenu({
		defaultText: 'Footer Menu E',
		className: 'vg-footermenu-select-122',
		subMenuDash: '&ndash;&ndash;'
	});
	$('.vg-footermenu-select-122').addClass('n_responsive_nav');
	$(".vg-footermenu-select-122").each(function(){  
		$(this).wrap('<div class="n_header_responsive_nav">');
	});
}); 
</script>
</div>

					</div>
		
				</div>
			</div>
		</div>

	</footer><!-- Footer Ends -->

</div>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-XXXXXXXX-X']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<script type="text/javascript">
jQuery(document).ready(function($){

	$("html").niceScroll({
		scrollspeed: 60,
		mousescrollstep: 35,
		cursorwidth: 10,
		cursorborder: 0,
		cursorcolor: '#00AAAA',
		cursorborderradius: 0,
		autohidemode: false,
		background: '#EAEAEA'
	});
	
});
</script>

</body>

<!-- Mirrored from 67.205.134.99/themes/news24/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 11 May 2017 05:50:33 GMT -->
</html>