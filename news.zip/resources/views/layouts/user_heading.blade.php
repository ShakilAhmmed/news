<!DOCTYPE html>
<html lang="en-gb" dir="ltr">

<!-- Mirrored from 67.205.134.99/themes/news24/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 11 May 2017 05:46:08 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
	
	  <base  />
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>News24</title>

  <link href="{{asset('user_asset/templates/vg_news24/favicon.ico')}}" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  @include('layouts.user_js')
  <script type="text/javascript">
jQuery(window).on('load',  function() {
				new JCaption('img.caption');
			});
  </script>
  <meta property="og:type" content="website" />


	
	<meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1.0, maximum-scale=1.0" />

	@include('layouts.user_css')
	
	<style>
	body, h1, h2, h3, h4, h5, h6, input, button, select, textarea, .navbar-search .search-query{ font-family:'Open Sans'; }
	.custom-class{} 
	</style>
	
	

</head>
<body class="clearfix hide-component" data-smooth-scrolling="1">

{{--FOR TICKER START--}}
<div class="n_page_wrapper">
	<header class="clearfix">

		<div class="n_content clearfix">

			<div class="row-fluid">
				<div class="span12">
					
					<a href="index-2.html" class="n_logo_container pull-left">
						<img src="{{asset('user_asset/images/logo/default-logo.png')}}" alt="News 24" width="auto" height="auto" />
					</a>				
					<div class="n_invisible_splitter"></div>