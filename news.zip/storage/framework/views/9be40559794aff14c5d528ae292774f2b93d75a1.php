
    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <!-- Animation library for notifications   -->
    <link href="<?php echo e(asset('css/animate.min.css')); ?>" rel="stylesheet"/>
    <!--  Paper Dashboard core CSS    -->
    <link href="<?php echo e(asset('css/paper-dashboard.css')); ?>" rel="stylesheet"/>
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo e(asset('css/demo.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('css/themify-icons.css')); ?>" rel="stylesheet">


