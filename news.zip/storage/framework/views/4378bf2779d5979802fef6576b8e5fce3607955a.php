

											<div class="n_stock_market_wrap "><div class="n_stock_market_wrapper">
	<div class="n_stock_market txt">
	<?php
	$latest_post=DB::table('post')->where('post_status','Active')->get();
    ?>
	<?php $__currentLoopData = $latest_post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest_post_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	   <div>
			<span style="font-size: 20px;color: #D3C5B4;"><a href="/single_post/<?php echo e($latest_post_value->post_id); ?>"><?php echo e($latest_post_value->post_title); ?></a></span>
		</div>
		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div></div>


											
				</div>
			</div>

		</div>

					<div class="n_top_line n_bgcolor"></div>
	</header><!-- Header Ends -->
	
	<div class="n_content clearfix">
