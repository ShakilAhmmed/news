
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:600,400' rel='stylesheet' type='text/css'>
	
	<link rel="stylesheet" href="<?php echo e(asset('user_asset/templates/system/css/system.css')); ?>" type="text/css" />
	<link href="<?php echo e(asset('user_asset/templates/vg_news24/css/bootstrap.css')); ?>" rel='stylesheet' type='text/css'>
	<link href="<?php echo e(asset('user_asset/templates/vg_news24/css/font-awesome.min.css')); ?>" rel="stylesheet" type='text/css'>
	<link href="<?php echo e(asset('user_asset/templates/vg_news24/css/tinyscrollbar.css')); ?>" rel="stylesheet" type='text/css'>
	
	<link href="<?php echo e(asset('user_asset/templates/vg_news24/css/light-style.css')); ?>" rel='stylesheet' type='text/css'>
	
	<link href="<?php echo e(asset('user_asset/templates/vg_news24/css/ticker.css')); ?>" rel='stylesheet' type='text/css'>
	<link href="<?php echo e(asset('user_asset/templates/vg_news24/css/joomla.css')); ?>" rel='stylesheet' type='text/css'>