<?php $__env->startSection('content'); ?>

<div class="row-fluid" id="vg-mainbody">
<div class="span8" id="vg-component">
			<div class="row-fluid" id="vg-component-inner">
				<div class="span12">
					<div id="system-message-container"></div>
				</div>
			</div>
			
			<div class="row-fluid carousel_block " style="margin-top: -250px;">
					<div class="span12">
			<div class="n_news_cat_list clearfix"><h4 class="pull-left n_news_cat_list_title" style="tab-size: 20px;font-size: 22px;font-weight: 500;margin-top: 10px"><?php echo e($post_value->catagory_name); ?></h4><div class="met_carousel_control clearfix">
	<a href="#"><i class="icon-angle-left"></i></a>
	<a href="#"><i class="icon-angle-right"></i></a>
</div>
<div class="n_splitter"><span class="n_bgcolor"></span></div>
	<div class="met_carousel_wrap">
		<div class="met_carousel clearfix">
                 
		          <div class="met_carousel_column"><div class="n_cat_list_image">
								<a href="/single_post/<?php echo e($post_value->post_id); ?>" class="n_news_cat_list_preview">
									<img src="<?php echo e(asset($post_value->post_image)); ?>" alt="Starting a new business"/>
								</a>
								<a href="/single_post/<?php echo e($post_value->post_id); ?>" class="n_image_hover_bg"><img src="<?php echo e($post_value->post_image); ?>" alt="" /></a>
							</div><a href="/single_post/<?php echo e($post_value->post_id); ?>" class="n_title_link"><h5 class="n_little_title" style="font-size: 24px;font-weight: 500;    margin-bottom: 20px;"><?php echo e($post_value->post_title); ?></h5></a>
						<p class="n_short_descr" style="font-size: 19px;line-height: 25px;font-weight: 500;"><?php echo e($post_value->post_description,250); ?></p>
						<?php if($post_value->sub_catagory_name=='-No Data Found-'): ?>
						<?php else: ?>
						<a href="/single_post/<?php echo e($post_value->post_id); ?>" style="font-size: 21px;font-weight: 500;" class="n_link n_color vg-category-carousel"><b><?php echo e($post_value->sub_catagory_name); ?></b></a>
						<?php endif; ?><img src="<?php echo e(asset('user_asset/templates/vg_news24/images/view-count.png')); ?>" alt="" class="n_view_count"><span class="n_view_counter" style="font-size: 17px;"><?php echo e($post_value->post_count); ?></span>
					</div>
  </div>
</div></div>
	</div>
	</div>
	<div class="comment">
	<span style="font-size: 24px;line-height: 68px;">Comments</span><br/>
	<?php if(auth()->guard()->guest()): ?>
      <a href="<?php echo e(route('login')); ?>">
      	<button class="btn btn-success" style="height: 48px;width: 86px;">Login</button>
      </a>
       <a href="<?php echo e(route('register')); ?>">
      	<button class="btn btn-warning" style="height: 48px;width: 86px;">Register</button>
      </a>
     <?php else: ?>
     <?php if(session('success')): ?>
     <div class="alert alert-success">
	  <strong>Success!</strong> <?php echo e(session('success')); ?>

	</div>
     <?php endif; ?>
	 <a href="<?php echo e(route('logout')); ?>" class ="btn btn-danger" onclick="event.preventDefault();document.getElementById('logout-form').submit();">
		Logout
      </a>
	  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

       </form><br/>
     <?php echo e(Form::open(['url'=>'/comment','method'=>'post'])); ?>

       <?php echo e(Form::hidden('user_id',Auth::user()->id)); ?>

       <?php echo e(Form::hidden('post_id',$post_value->post_id)); ?>

       <?php echo e(Form::textarea('comment','',['cols'=>'60','rows'=>'5','placeholder'=>'Write Your Comment'])); ?>

       <span style="color: red"><?php echo e($errors->first('comment')); ?></span>
       <?php echo e(Form::hidden('comment_status','Inactive')); ?>

      <?php echo e(Form::submit('Submit',['class'=>'btn btn-success'])); ?>

      <?php echo e(Form::close()); ?>

     <?php endif; ?>
     <div>
       <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($v_comment->post_id==$post_value->post_id): ?>
     	<label style="font-size: 19px;"><i class="fas fa-user"></i>&nbsp;<?php echo e($v_comment->name); ?></label>
     	<p style="font-size: 19px;line-height: 37px;font-weight: 500"><?php echo e($v_comment->comment); ?></p>
        <?php endif; ?>
     	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </div>

    </div>
</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>