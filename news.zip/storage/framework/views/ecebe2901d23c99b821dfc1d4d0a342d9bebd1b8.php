<div class="col-md-12">
              <div class="card">
                  <div class="content table-responsive table-full-width">
                      <table class="table table-hover">
                          <thead>
                            <th>Sl No</th>
                            <th>Catagory Name</th>
                            <th>Catagory Title</th>
                            <th>Status</th>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $catagory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$catagory_data_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($catagory_data_value->catagory_name); ?></td>
                                <td><?php echo e($catagory_data_value->catagory_title); ?></td>
                                <td>
                              <?php if($catagory_data_value->catagory_status=='Active'): ?>
                                 <span style="color:green;">
                                  <i class="fa fa-circle" aria-hidden="true"></i> <?php echo e($catagory_data_value->catagory_status); ?>

                                 </span>
                              <?php else: ?>
                               <span style="color:red;">
                                  <i class="fa fa-circle" aria-hidden="true"></i> <?php echo e($catagory_data_value->catagory_status); ?>

                                 </span>
                              <?php endif; ?>


                                 </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                  </div>
              </div>
         </div>