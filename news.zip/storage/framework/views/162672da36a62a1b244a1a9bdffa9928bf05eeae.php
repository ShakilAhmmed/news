<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <?php echo $__env->make('layouts.side_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
      <?php echo $__env->make('layouts.nav_bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="content">
            <?php echo $__env->yieldContent('main_content'); ?>
        </div>
      <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <?php echo $__env->make('layouts.js_link', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <?php echo $__env->make('layouts.extra_js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
