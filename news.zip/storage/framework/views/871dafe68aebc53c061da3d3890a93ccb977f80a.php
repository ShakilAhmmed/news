
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('js/jquery-1.10.2.js')); ?>" type="text/javascript"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="<?php echo e(asset('js/bootstrap-checkbox-radio.js')); ?>"></script>

	<!--  Charts Plugin -->
	<script src="<?php echo e(asset('js/chartist.min.js')); ?>"></script>

    <!--  Notifications Plugin    -->
    <script src="<?php echo e(asset('js/bootstrap-notify.js')); ?>"></script>

    <!--  Google Maps Plugin    -->
   

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="<?php echo e(asset('js/paper-dashboard.js')); ?>"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="<?php echo e(asset('js/demo.js')); ?>"></script>
	<script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>