			<div class="span2" id="vg-right-a" style="margin-top: -250px;">

				<div class="row-fluid">
					<div class="span12">
					
						<h4 class="n_news_cat_list_title">LATEST POSTS <small>   Subtitle</small></h4><div class="vg-right-a "><div class="n_latest_post_container clearfix"><a href="index.php/blog/62-consuming-spending-edges.html" class="n_latest_post_picture"><img src="images/blog/1.jpg" alt="Consuming spending edges" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/62-consuming-spending-edges.html" class="n_title_link"><h5 class="n_little_title">Consuming spending edges</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/63-hot-to-ensure-strong-job.html" class="n_latest_post_picture"><img src="images/blog/2.jpg" alt="Hot to ensure strong job" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/63-hot-to-ensure-strong-job.html" class="n_title_link"><h5 class="n_little_title">Hot to ensure strong job</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/64-starting-a-new-business.html" class="n_latest_post_picture"><img src="images/blog/3.jpg" alt="Starting a new business" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/64-starting-a-new-business.html" class="n_title_link"><h5 class="n_little_title">Starting a new business</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/65-taxes-are-killing-the-poor-people.html" class="n_latest_post_picture"><img src="images/blog/4.jpg" alt="Taxes are killing the poor people" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/65-taxes-are-killing-the-poor-people.html" class="n_title_link"><h5 class="n_little_title">Taxes are killing the poor people</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/66-war-of-power-in-mexico.html" class="n_latest_post_picture"><img src="images/blog/5.jpg" alt="War of power in Mexico" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/66-war-of-power-in-mexico.html" class="n_title_link"><h5 class="n_little_title">War of power in Mexico</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/72-consuming-spending-edges-3.html" class="n_latest_post_picture"><img src="images/blog/6.jpg" alt="Consuming spending edges" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/72-consuming-spending-edges-3.html" class="n_title_link"><h5 class="n_little_title">Consuming spending edges</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/73-hot-to-ensure-strong-job-3.html" class="n_latest_post_picture"><img src="images/blog/7.jpg" alt="Hot to ensure strong job" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/73-hot-to-ensure-strong-job-3.html" class="n_title_link"><h5 class="n_little_title">Hot to ensure strong job</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/74-starting-a-new-business-3.html" class="n_latest_post_picture"><img src="images/blog/8.jpg" alt="Starting a new business" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/74-starting-a-new-business-3.html" class="n_title_link"><h5 class="n_little_title">Starting a new business</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/75-taxes-are-killing-the-poor-people-3.html" class="n_latest_post_picture"><img src="images/blog/9.jpg" alt="Taxes are killing the poor people" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/75-taxes-are-killing-the-poor-people-3.html" class="n_title_link"><h5 class="n_little_title">Taxes are killing the poor people</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div><div class="n_latest_post_container clearfix"><a href="index.php/blog/76-war-of-power-in-mexico-3.html" class="n_latest_post_picture"><img src="images/blog/10.jpg" alt="War of power in Mexico" class="vg-latest-post" /></a><div class="n_latest_post_details">
							<a href="index.php/blog/76-war-of-power-in-mexico-3.html" class="n_title_link"><h5 class="n_little_title">War of power in Mexico</h5></a>
							<span class="n_little_date">Published: Wednesday, 22 May 2013 07:06</span>
						</div>
					</div></div><div class="vg-right-a ">

<div class="custom"  >
	<p style="margin-top: 20px;"><img class="vg-fullwidth" src="images/ads/1.png" alt="" /></p></div>
</div>
						
					</div>
				</div>

			</div>

			

	

	</div>
	<!-- /MAINBODY -->
	
			<div class="n_splitter"><span class="n_bgcolor"></span></div>
		
		<div class="row-fluid">
			
							<div class="span12">
					<div class="vg-bottom ">
<div class="VombieLikeButton">

	<iframe 
		id="facebookLikeButton"
		src="http://www.facebook.com/plugins/like.php?locale=en_GB&amp;href=http://www.facebook.com/envato&amp;send=true&amp;layout=standard&amp;show_faces=true&amp;width=100&amp;height=50&amp;font=arial&amp;action=like&amp;colorscheme=light&amp;appId=" 
		scrolling="no" 
		frameborder="0" 
		style="border:none; overflow:hidden;"
		allowTransparency="true">
	</iframe> 
	
</div></div>
				</div>
															
		</div>
		
	</div><!-- Middle Content Ends -->